// Project: Name Repeater with Loop
// Description: Prints "Sri Hari is Learning C!" multiple times using different loop types (for, while, do-while).
// Language: C
// Author: Sri Hari
// Date: July 2025

#include <stdio.h>

int main() {
    for (int i = 1; i <= 5; i++) {
        printf("Sri Hari is Learning C!\n");
    }

    return 0;
}

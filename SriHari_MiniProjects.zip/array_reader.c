// Project: Array Reader
// Description: Stores a set of integers in an array and prints them using a loop with index.
// Language: C
// Author: Sri Hari
// Date: July 2025

#include <stdio.h>

int main() {
    int numbers[5] = {7, 14, 20, 40, 50};

    for (int i = 0; i < 5; i++) {
        printf("numbers[%d] = %d\n", i, numbers[i]);
    }

    return 0;
}

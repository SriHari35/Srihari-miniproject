// Project: Even or Odd Number Printer
// Description: Prints either even or odd numbers between 1 and a given range using loops.
// Language: C
// Author: Sri Hari
// Date: July 2025

#include <stdio.h>

int main() {
    int n;

    printf("Enter the range limit: ");
    scanf("%d", &n);

    printf("Even numbers from 1 to %d:\n", n);
    for (int i = 1; i <= n; i++) {
        if (i % 2 == 0) {
            printf("%d ", i);
        }
    }
    printf("\n");

    return 0;
}

// Project: Grade Evaluator
// Description: Takes a single character input for grade (A, B, C, etc.) and displays a message like "Excellent", "Good", etc.
// Language: C
// Author: Sri Hari
// Date: July 2025

#include <stdio.h>

int main() {
    char grade;

    printf("Enter your Grade (A/B/C/D/F): ");
    scanf(" %c", &grade);

    switch (grade) {
        case 'A':
            printf("Excellent!\n");
            break;
        case 'B':
            printf("Very Good!\n");
            break;
        case 'C':
            printf("Good\n");
            break;
        case 'D':
            printf("Needs Improvement\n");
            break;
        case 'F':
            printf("Fail\n");
            break;
        default:
            printf("Invalid Grade\n");
    }

    return 0;
}
